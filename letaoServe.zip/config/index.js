// password 盐
module.exports.passwordSecret = "letao";
// JWT 秘钥
module.exports.jwtSecret = "letaojwt";
